#!/usr/bin/env python3

from math import pi
import cairo

def draw(cr, width, height):
    LINES = 32
    MAX_THETA = 0.80 * pi * 2
    THETA_INC = 2.0 * MAX_THETA / (LINES - 1)

    cr.set_source_rgb(0, 0, 0)
    cr.set_line_width(2.0)

    cr.save()

    cr.translate(width / 2, height / 2)
    cr.rotate(MAX_THETA)

    for i in range(LINES):
        cr.move_to(-2 * width, 0)
        cr.line_to(2 * width, 0)
        cr.stroke()

        cr.rotate(- THETA_INC)

    cr.restore()

    cr.set_line_width(6)
    cr.set_source_rgb(1, 0, 0)

    cr.move_to(width / 4.0, 0)
    cr.rel_line_to(0, height)
    cr.stroke()

    cr.move_to(3 * width / 4.0, 0)
    cr.rel_line_to(0, height)
    cr.stroke()


if __name__ == '__main__':
    width, height = 256, 265
    surface = cairo.SVGSurface("demo13.svg", width, height)
    cr = cairo.Context(surface)
    cr.save()

    draw(cr, width, height)

    cr.restore()
    cr.show_page()
    surface.finish()
