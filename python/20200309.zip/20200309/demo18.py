#!/usr/bin/env python3

import cairo

def draw(cr, width, height):
    wd = .02 * width
    hd = .02 * height

    width -= 2
    height -= 2

    cr.move_to(width + 1, 1 - hd)
    for i in range(9):
        cr.rel_line_to(0, height - hd * (2 * i - 1))
        cr.rel_line_to(-(width - wd * (2 * i)), 0)
        cr.rel_line_to(0, -(height - hd * (2 * i)))
        cr.rel_line_to(width - wd * (2 * i + 1), 0)

    cr.set_source_rgb(0, 0, 1)
    cr.stroke()
    

if __name__ == '__main__':
    width, height = 256, 265
    surface = cairo.SVGSurface("demo18.svg", width, height)
    cr = cairo.Context(surface)
    cr.save()

    draw(cr, width, height)

    cr.restore()
    cr.show_page()
    surface.finish()
