#!/usr/bin/env python3

from math import pi
import cairo

width, height = 256, 265
surface = cairo.SVGSurface("demo01.svg", width, height)
cr = cairo.Context(surface)

cr.save()
cr.scale(width, height)
cr.set_line_width(0.04)

xc, yc = 0.5, 0.5
radius = 0.4

angle1 = 45.0 * (pi / 180.0)
angle2 = 180.0 * (pi / 180.0)

cr.arc(xc, yc, radius, angle1, angle2)
cr.stroke()

cr.set_source_rgba(1, 0.2, 0.2, 0.6)
cr.arc(xc, yc, 0.05, 0, 2 * pi)
cr.fill()

cr.set_line_width(0.03)
cr.arc(xc, yc, radius, angle1, angle2)
cr.line_to(xc, yc)
cr.arc(xc, yc, radius, angle2, angle2)
cr.line_to(xc, yc)
cr.stroke()

cr.restore()
cr.show_page()
surface.finish()
