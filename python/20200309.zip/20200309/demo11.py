#!/usr/bin/env python3

from math import pi
import cairo

def draw(cr, width, height):
    cr.scale(width, height)
    cr.set_line_width(0.04)

    pat = cairo.LinearGradient(0.0, 0.0, 1.0, 1.0)
    pat.add_color_stop_rgb(0, 0, 0.3, 0.8)
    pat.add_color_stop_rgb(1, 0, 0.8, 0.3)

    mask = cairo.RadialGradient(0.5, 0.5, 0.25, 0.5, 0.5, 0.5)
    mask.add_color_stop_rgba(0, 0, 0, 0, 1)
    mask.add_color_stop_rgba(0.5, 0, 0, 0, 0)

    cr.set_source(pat)
    cr.mask(mask)

if __name__ == '__main__':
    width, height = 256, 265
    surface = cairo.SVGSurface("demo11.svg", width, height)
    cr = cairo.Context(surface)
    cr.save()

    draw(cr, width, height)

    cr.restore()
    cr.show_page()
    surface.finish()
