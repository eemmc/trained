#!/usr/bin/env python3

from math import pi
import cairo

def draw(cr, width, height):
    cr.scale(width, height)
    cr.set_line_width(0.04)

    cr.move_to(0.5, 0.1)
    cr.line_to(0.9, 0.9)
    cr.rel_line_to(-0.4, 0.0)
    cr.curve_to(0.2, 0.9, 0.2, 0.5, 0.5, 0.5)
    cr.close_path()
    
    cr.set_source_rgb(0, 0, 1)
    cr.fill_preserve()
    cr.set_source_rgb(0, 0, 0)
    cr.stroke()

if __name__ == '__main__':
    width, height = 256, 265
    surface = cairo.SVGSurface("demo07.svg", width, height)
    cr = cairo.Context(surface)
    cr.save()

    draw(cr, width, height)

    cr.restore()
    cr.show_page()
    surface.finish()
